exports.prefixo = "s."

exports.GOOGLE_API_KEY = "NzkwNzg1NDU2NzczMTM2Mzg0.X-FqWA.ZRuqr_RUVkahYJyqtwDtHOG4gUs"

exports.GENIUS_API_KEY = "VE-Hkn049y3FN2oYctEIL1Kc6eCaORIrNNaPXKqihSHTJqWjnvh4FFm67Upgo5Jj";

exports.yandex_API = "trnsl.1.1.20200524T161905Z.bfe2aa5a35ce8bd9.2e55fde04fbce222eb14506eba89f1dbfcfc973d";

exports.news_API = "ac620cf6a0aa49b398f8f071edcaa71f";

exports.giphy_API = "RmKm0HixW7lQ6F8cTSQpyWaj0bjT7laH";

exports.AME_API = "a0f7f1b61e152b375952b83d2b6a7ae64c32fdc2fcc7a4f6b6963dc4c447731745c451adabde6a070731bb99739c68350668074b7fcec856e8222a75ab7da555";

exports.blague_API = "r.00yqXn3KtkY41GNdGCB._JbaMPdqyAyLA6JLkCjftATM5QXTvdatalXNzvcBR-";